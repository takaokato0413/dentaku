//
//  ViewController.swift
//  電卓_codecamp2016_takao_kato
//
//  Created by takao kato on 2017/01/17.
//  Copyright © 2017年 takao kato. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var sum: UILabel!
    
    
    
     var Number : Int = 0
    var nextstep : String?

    
    var syori: Bool = false
 
    
   @IBAction func zero(_ sender: UIButton) {
    
        let zero = sender.currentTitle
    if syori{
        sum.text = sum.text! + zero!
    } else {
        sum.text = zero
        syori = true
    }
   //     sum.text = sum.text! + zero!
    }
    
    
    @IBAction func equall(_ sender: UIButton) {
        
        if sender.currentTitle == "C" {
            Number = 0
            nextstep = nil
            
        }
    }
    override func didReceiveMemoryWarning()
        
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}


//   @IBAction func clear(_ sender: UIButton) {
//  }

//   @IBAction func syou(_ sender: UIButton) {
//  }
//   @IBAction func seki(_ sender: UIButton) {
//  }
// @IBAction func minus(_ sender: UIButton) {
//   }
//  @IBAction func plus(_ sender: UIButton) {
//   }
//  @IBAction func equall(_ sender: UIButton) {
//  }

  //  @IBAction func one(_ sender: UIButton) {
//        let one = sender.currentTitle
 //       sum.text = sum.text! + one!
 //       print("sum = \(sum)")
 //   }
  //  @IBAction func two(_ sender: UIButton) {
  //      let two = sender.currentTitle
   //     sum.text = sum.text! + two!
   // }
  //  @IBAction func three(_ sender: UIButton) {
   //     let three = sender.currentTitle
    //    sum.text = sum.text! + three!
  //  }
  //  @IBAction func four(_ sender: UIButton) {
   //     let four = sender.currentTitle
   //     sum.text = sum.text! + four!
   // }
   // @IBAction func five(_ sender: UIButton) {
   //     let five = sender.currentTitle
   //     sum.text = sum.text! + five!
   // }
   // @IBAction func six(_ sender: UIButton) {
   // }
    
  //  @IBAction func seven(_ sender: UIButton) {
   // }
   
   // @IBAction func eight(_ sender: UIButton) {
 //   }
    
    
  //  @IBAction func nine(_ sender: UIButton) {

